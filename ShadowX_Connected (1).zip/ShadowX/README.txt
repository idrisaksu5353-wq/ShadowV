ShadowX
Open index.html in a modern browser.

Features:
- Connected Home, Games, AI, Music, Movies & TV, Userscripts and Settings tabs
- Working top navigation buttons
- Search/address bar
- Add Game with HTML code and picture URL
- Games saved in browser localStorage
- Local ShadowX AI chat
- Fullscreen, bookmark and menu buttons

Important:
The AI included here is a local browser assistant, so it does not require an API key.
Google Drive can store the ZIP, but Drive is not a normal web host for running an HTML app.
For a public playable website, upload the extracted files to GitHub Pages, Netlify, or another static host.
